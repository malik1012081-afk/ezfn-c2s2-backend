<div align=center>
  <img src="https://i.ibb.co/Bcj3VXm/68747470733a2f2f63646e2e646973636f72646170702e636f6d2f6174746163686d656e74732f3932373733393930313534.png" alt="LawinServer Logo">

  ### LawinServer is a private server that supports all Fortnite versions!
  
</div>
<br>

## Credits
| Name | Contributions |
| --------------- | ----------- |
| [Lawin](https://github.com/Lawin0129) | Creator |
| [PRO100KatYT](https://github.com/PRO100KatYT) | Contributor & Maintainer |

## Features:

### Save the World:
- CloudStorage and ClientSettings (Settings saving)
- Llama purchasing and opening with random loot and choice packs
- Every Hero, Weapon, Defender and Resource
- All Founder's Packs rewards screen (togglable in the config)
- Refreshing, sending, collecting and aborting expeditions
- Crafting items in Backpack
- Transferring items to and from Storage
- Modifying and upgrading Schematic perks
- Supercharging items
- Leveling up and Evolving items
- Upgrading item rarity
- Hero, Defender, Survivor, Team Perk and Gadget equipping
- Research level resetting and upgrading
- Upgrade level resetting and upgrading
- Autofill survivors
- Recycling and destroying items
- Collection Book slotting and unslotting
- Claiming Daily Rewards
- Claiming Quest and Collection Book Rewards
- Modifying quickbars in Backpack
- Activating XP Boosts
- Correct Events in Frontend up to Season 11 (Can change)
- Buying Skill Tree perks
- Quests pinning
- Switching between Hero Loadouts
- Favoriting items
- Marking items as seen
- Setting the Homebase name
- Changing items in Locker
- Changing banner icon and banner color
- Changing items edit styles
- Support a Creator with specific codes
- Fully working daily challenges system (New daily challenge every day, replacing daily challenges, etc...)
- Item transformation
- Item to Schematic Research
- Event Quests from Season 2 up to Season X & Season 24 (Can change)

### Battle Royale:
- CloudStorage and ClientSettings (Settings saving)
- Winterfest presents opening (11.31, 19.01, 23.10, 33.11 & 39.11)
- Purchasing Item Shop items
- Refunding cosmetics in the refund tab
- Favoriting items
- Marking items as seen
- Changing items in Locker
- Changing banner icon and banner color
- Changing items edit styles
- Jam Track playback in lobby (28.00-30.00) (Currently all tracks will play the OG Future Remix audio)
- Radio Station in cars support*
- Support a Creator with specific codes
- Fully working daily challenges system (New daily challenge every day, replacing daily challenges, etc...)
- Completed Named Locations & Landmarks discovery quests (discovered map in game & in lobby) for Chapter 2 - 6 (Can change)
- Seasonal Quests from Season 3 up to Season 40 (Can change)
- Purchasable battle pass from Season 2 to Season 10 (Can change)
- Events Tab (Tournaments)
- Discovery Tab
- Leaderboards (v1)
- Configurable backend sided in-game events - check out the Events section in config.ini for more details
- Joining gameservers using the matchmaker - check out the GameServer section in config.ini for more details
##### * Included in the [LawinServer Addon](https://github.com/PRO100KatYT/LawinServerAddon). To install it, merge its `public` folder with the one in your LawinServer folder. [(Direct download link)](https://github.com/PRO100KatYT/LawinServerAddon/archive/refs/heads/main.zip)

## How to host/use LawinServer
1) Install [NodeJS](https://nodejs.org/en/)
2) Run "install_packages.bat" (This file isn't required after the packages are installed.)
3) Run "start.bat", It should say "Started listening on port 3551"
4) Use something to redirect the fortnite servers to localhost:3551 (Which could be fiddler, ssl bypass that redirects servers, etc...)

<details>
<summary>Looking for the FiddlerScript? Click here to reveal.</summary>

```javascript
import Fiddler;

class Handlers
{
    static function OnBeforeRequest(oSession: Session) {
        if (oSession.hostname.Contains("epic") && !oSession.fullUrl.Contains("/v1/item/"))
        {
            if (oSession.HTTPMethodIs("CONNECT"))
            {
                oSession["x-replywithtunnel"] = "BackendTunnel";
                return;
            }
            oSession.fullUrl = "http://127.0.0.1:3551" + oSession.PathAndQuery;
        }
    }   
}
```

</details>
